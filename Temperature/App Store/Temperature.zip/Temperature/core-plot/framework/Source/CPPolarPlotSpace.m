
#import "CPPolarPlotSpace.h"

/**	@brief A plot space using a two-dimensional polar coordinate system.
 *	@note Not implemented.
 *	@todo Implement CPPolarPlotSpace.
 **/
@implementation CPPolarPlotSpace

@end
