
#import <Foundation/Foundation.h>
#import "CPXYTheme.h"

@interface CPPlainWhiteTheme : CPXYTheme {

}

@end
