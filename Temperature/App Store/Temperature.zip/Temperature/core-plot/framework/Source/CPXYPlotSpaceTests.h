
#import "CPTestCase.h"

@class CPXYGraph;

@interface CPXYPlotSpaceTests : CPTestCase {
    CPXYGraph *graph;
}

@property (retain,readwrite) CPXYGraph *graph;

@end
