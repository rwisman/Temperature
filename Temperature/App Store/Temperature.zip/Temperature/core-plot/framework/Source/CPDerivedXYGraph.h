#import "CPXYGraph.h"

@interface CPDerivedXYGraph : CPXYGraph {

}

@end
