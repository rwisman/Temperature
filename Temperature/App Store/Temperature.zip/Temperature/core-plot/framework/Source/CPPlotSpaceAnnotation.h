#import <Foundation/Foundation.h>
#import "CPAnnotation.h"

@interface CPPlotSpaceAnnotation : CPAnnotation {

}

@end
