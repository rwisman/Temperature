#import "CPTestCase.h"

@interface CPDarkGradientThemeTests : CPTestCase {
}

@end
