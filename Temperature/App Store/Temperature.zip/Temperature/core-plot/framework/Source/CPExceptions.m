
#import "CPExceptions.h"

NSString * const CPException     = @"CPException";		///< General Core Plot exceptions.
NSString * const CPDataException = @"CPDataException";	///< Core Plot data exceptions.
