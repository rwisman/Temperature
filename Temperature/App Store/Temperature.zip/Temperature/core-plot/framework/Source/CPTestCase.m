//
//  CPTestCase.m
//  CorePlot
//
//  Created by Drew McCormack on 25/10/09.
//  Copyright 2009 The Mental Faculty. All rights reserved.
//

#import "CPTestCase.h"


@implementation CPTestCase

@end
