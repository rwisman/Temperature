#import <Foundation/Foundation.h>
#import "CPLayer.h"

@interface CPAxisLabelGroup : CPLayer {

}

@end
