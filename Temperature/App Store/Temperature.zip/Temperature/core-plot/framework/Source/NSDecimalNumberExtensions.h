#import <Foundation/Foundation.h>
#import <QuartzCore/QuartzCore.h>

@interface NSDecimalNumber(CPExtensions)

-(CGFloat)floatValue;

@end
