#import "CPTestCase.h"

@interface CPThemeTests : CPTestCase {

}

@end
