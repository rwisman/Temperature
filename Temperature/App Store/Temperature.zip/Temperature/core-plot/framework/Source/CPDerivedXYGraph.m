#import "CPDerivedXYGraph.h"

/**	@brief An empty XY graph class used for testing themes.
 **/
@implementation CPDerivedXYGraph

@end
