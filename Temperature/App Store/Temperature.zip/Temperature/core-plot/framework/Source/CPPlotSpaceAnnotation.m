#import "CPPlotSpaceAnnotation.h"

/**	@brief Positions a content layer relative to some anchor point in a plot space.
 *	@note Not implemented.
 *	@todo More documentation needed.
 *	@todo Implement CPPlotSpaceAnnotation.
 **/
@implementation CPPlotSpaceAnnotation

@end
