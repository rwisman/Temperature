#import "CPTestCase.h"

@interface CPTextStyleTests : CPTestCase {

}

@end
