
#import <Foundation/Foundation.h>
#import "CPPlotSpace.h"

@interface CPPolarPlotSpace : CPPlotSpace {
    
}

@end
