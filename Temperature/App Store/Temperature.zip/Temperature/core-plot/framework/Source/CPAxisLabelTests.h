
#import "CPTestCase.h"

@interface CPAxisLabelTests : CPTestCase {

}

@end
