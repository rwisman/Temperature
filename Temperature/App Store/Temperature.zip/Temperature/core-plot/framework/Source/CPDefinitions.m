
#import "CPDefinitions.h"

const CGFloat CPDefaultZPositionAxis = 0;			///< Default Z position for CPAxis.
const CGFloat CPDefaultZPositionAxisSet = 0;		///< Default Z position for CPAxisSet.
const CGFloat CPDefaultZPositionGraph = 0;			///< Default Z position for CPGraph.
const CGFloat CPDefaultZPositionPlot = 0;			///< Default Z position for CPPlot.
const CGFloat CPDefaultZPositionPlotArea = 0;		///< Default Z position for CPPlotArea.
const CGFloat CPDefaultZPositionPlotAreaFrame = 0;	///< Default Z position for CPPlotAreaFrame.
const CGFloat CPDefaultZPositionPlotGroup = 0;		///< Default Z position for CPPlotGroup.
