#import "CorePlot-CocoaTouch.h"
#import "PlotController.h"

@interface TemperaturePlotController : PlotController
{}
@end
