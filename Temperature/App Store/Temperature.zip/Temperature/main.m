//
//  main.m
//  Acceleration
//
//  Created by Brad Larson on 5/11/2009.
//	Modified by Ray Wisman on July 31, 2010
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, nil);
    [pool release];
    return retVal;
}

